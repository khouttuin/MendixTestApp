//>>built
define("dijit/ConfirmTooltipDialog",["dojo/_base/declare","./TooltipDialog","./_ConfirmDialogMixin"],function(_1,_2,_3){
return _1("dijit.ConfirmTooltipDialog",[_2,_3],{});
});
